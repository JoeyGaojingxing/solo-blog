title: 我在 GitHub 上的开源项目
date: '2019-07-26 14:42:18'
updated: '2019-07-26 14:42:18'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/JoeyGaojingxing/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/JoeyGaojingxing/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.mojerro.wang`](http://www.mojerro.wang "项目主页")</span>

Mojerro的安乐窝 - 喜欢生物和射箭，Python和Go开发者



---

### 2. [NatureTrail-wechat](https://github.com/JoeyGaojingxing/NatureTrail-wechat) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/NatureTrail-wechat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/NatureTrail-wechat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/NatureTrail-wechat/network/members "分叉数")</span>

方圆草木微信小程序



---

### 3. [CS231n-assignments](https://github.com/JoeyGaojingxing/CS231n-assignments) <kbd title="主要编程语言">Jupyter Notebook</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/CS231n-assignments/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/CS231n-assignments/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/CS231n-assignments/network/members "分叉数")</span>

the 3 assignments of CS231n in Spring 2019



---

### 4. [qnhszm](https://github.com/JoeyGaojingxing/qnhszm) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/qnhszm/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/qnhszm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/qnhszm/network/members "分叉数")</span>

青年红色筑梦之旅官方网站 Vue前端 Youth red dream tour front-end by Vue



---

### 5. [qnhszm-flask](https://github.com/JoeyGaojingxing/qnhszm-flask) <kbd title="主要编程语言">Jupyter Notebook</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/qnhszm-flask/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/qnhszm-flask/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/qnhszm-flask/network/members "分叉数")</span>





---

### 6. [dataStructureByGo](https://github.com/JoeyGaojingxing/dataStructureByGo) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/dataStructureByGo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/dataStructureByGo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/dataStructureByGo/network/members "分叉数")</span>





---

### 7. [QtLearn](https://github.com/JoeyGaojingxing/QtLearn) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/QtLearn/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/QtLearn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/QtLearn/network/members "分叉数")</span>

learn Qt with python



---

### 8. [ACAC](https://github.com/JoeyGaojingxing/ACAC) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/ACAC/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/ACAC/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/ACAC/network/members "分叉数")</span>

This is an Archery regist and manage system.



---

### 9. [tulips-tree](https://github.com/JoeyGaojingxing/tulips-tree) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/JoeyGaojingxing/tulips-tree/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/JoeyGaojingxing/tulips-tree/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/JoeyGaojingxing/tulips-tree/network/members "分叉数")</span>

A photograph-based social website.

